import { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Lock, User, Star, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login/register
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-accent/30 to-muted flex items-center justify-center p-4">
      <div className="max-w-6xl w-full grid md:grid-cols-2 gap-8 items-center">
        {/* Left Side - Illustration */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          className="hidden md:block"
        >
          <div className="relative">
            <div className="relative z-10 bg-white/80 backdrop-blur rounded-3xl p-8 shadow-2xl">
              <Star className="h-16 w-16 text-primary fill-primary mb-4" />
              <h2 className="text-3xl font-black mb-4">
                Welcome to <span className="text-primary">KIDO!</span>
              </h2>
              <p className="text-gray-600 mb-6">
                Join thousands of happy parents who trust KIDO for safe, fun, and educational toys.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                    <Heart className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold">Safe & Trusted</p>
                    <p className="text-sm text-gray-600">All toys meet safety standards</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                    <Star className="h-5 w-5 text-white fill-white" />
                  </div>
                  <div>
                    <p className="font-semibold">Top Rated</p>
                    <p className="text-sm text-gray-600">Loved by kids and parents</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <motion.div
              animate={{ y: [0, -20, 0] }}
              transition={{ repeat: Infinity, duration: 4 }}
              className="absolute -top-6 -right-6 bg-secondary text-white p-6 rounded-3xl shadow-2xl z-0"
            >
              <p className="text-2xl font-black">10K+</p>
              <p className="text-sm">Happy Families</p>
            </motion.div>
          </div>
        </motion.div>

        {/* Right Side - Form */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-3xl p-8 md:p-10 shadow-2xl"
        >
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Star className="h-10 w-10 text-primary fill-primary" />
              <span className="text-3xl font-black text-primary">KIDO</span>
            </div>
            <h2 className="text-2xl font-black mb-2">
              {isLogin ? 'Welcome Back!' : 'Create Account'}
            </h2>
            <p className="text-gray-600">
              {isLogin ? 'Login to continue shopping' : 'Sign up to start your journey'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block mb-2 font-semibold">Full Name</label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="w-full p-4 pl-12 rounded-2xl border-2 border-border bg-input-background"
                    placeholder="John Doe"
                  />
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                </div>
              </div>
            )}

            <div>
              <label className="block mb-2 font-semibold">Email</label>
              <div className="relative">
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="w-full p-4 pl-12 rounded-2xl border-2 border-border bg-input-background"
                  placeholder="you@example.com"
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              </div>
            </div>

            <div>
              <label className="block mb-2 font-semibold">Password</label>
              <div className="relative">
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  className="w-full p-4 pl-12 rounded-2xl border-2 border-border bg-input-background"
                  placeholder="••••••••"
                />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              </div>
            </div>

            {isLogin && (
              <div className="flex justify-between items-center text-sm">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="rounded" />
                  <span>Remember me</span>
                </label>
                <a href="#" className="text-primary hover:underline">
                  Forgot password?
                </a>
              </div>
            )}

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full bg-secondary hover:bg-secondary/90 text-white py-4 rounded-full font-bold text-lg shadow-lg"
            >
              {isLogin ? 'Login' : 'Create Account'}
            </motion.button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isLogin ? "Don't have an account? " : 'Already have an account? '}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="text-primary font-bold hover:underline"
              >
                {isLogin ? 'Sign Up' : 'Login'}
              </button>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t text-center">
            <Link to="/" className="text-gray-600 hover:text-primary">
              ← Back to Home
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
