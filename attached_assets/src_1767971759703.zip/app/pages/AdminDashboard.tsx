import { motion } from 'motion/react';
import { DollarSign, Package, ShoppingCart, Users, TrendingUp, Eye, Edit, Trash2 } from 'lucide-react';
import { products } from '../data/products';

export function AdminDashboard() {
  const stats = [
    { icon: DollarSign, label: 'Total Revenue', value: '$45,231', change: '+12.5%', color: 'bg-primary' },
    { icon: ShoppingCart, label: 'Orders', value: '1,234', change: '+8.2%', color: 'bg-secondary' },
    { icon: Package, label: 'Products', value: products.length.toString(), change: '+3', color: 'bg-accent' },
    { icon: Users, label: 'Customers', value: '10,456', change: '+18.7%', color: 'bg-muted' },
  ];

  const recentOrders = [
    { id: '#1234', customer: 'Sarah Johnson', product: 'Super Speed Racing Car', amount: '$29.99', status: 'Delivered' },
    { id: '#1235', customer: 'Michael Chen', product: 'Princess Dress-Up Doll', amount: '$34.99', status: 'Shipped' },
    { id: '#1236', customer: 'Emily Rodriguez', product: 'Educational Building Blocks', amount: '$24.99', status: 'Processing' },
    { id: '#1237', customer: 'David Kim', product: 'Family Board Game', amount: '$39.99', status: 'Delivered' },
    { id: '#1238', customer: 'Lisa Anderson', product: 'Monster Truck Collection', amount: '$44.99', status: 'Shipped' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted/30 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl md:text-4xl font-black mb-2">
            Admin <span className="text-primary">Dashboard</span>
          </h1>
          <p className="text-gray-600 mb-8">Manage your KIDO store</p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-2xl`}>
                  <stat.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-green-600 font-semibold">{stat.change}</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
              <p className="text-2xl font-black">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Orders */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-3xl p-6 shadow-lg"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-bold text-xl">Recent Orders</h2>
                <button className="text-primary hover:text-secondary font-semibold text-sm">
                  View All
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-2 font-semibold text-sm">Order ID</th>
                      <th className="text-left py-3 px-2 font-semibold text-sm">Customer</th>
                      <th className="text-left py-3 px-2 font-semibold text-sm">Product</th>
                      <th className="text-left py-3 px-2 font-semibold text-sm">Amount</th>
                      <th className="text-left py-3 px-2 font-semibold text-sm">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="py-4 px-2 font-semibold">{order.id}</td>
                        <td className="py-4 px-2">{order.customer}</td>
                        <td className="py-4 px-2 text-sm">{order.product}</td>
                        <td className="py-4 px-2 font-semibold text-primary">{order.amount}</td>
                        <td className="py-4 px-2">
                          <span
                            className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                              order.status === 'Delivered'
                                ? 'bg-green-100 text-green-800'
                                : order.status === 'Shipped'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {order.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </div>

          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-3xl p-6 shadow-lg mb-8"
            >
              <h2 className="font-bold text-xl mb-6">Quick Actions</h2>
              <div className="space-y-3">
                <button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-2xl font-semibold transition-colors">
                  Add New Product
                </button>
                <button className="w-full bg-secondary hover:bg-secondary/90 text-white py-3 rounded-2xl font-semibold transition-colors">
                  Process Orders
                </button>
                <button className="w-full bg-accent hover:bg-primary/20 text-foreground py-3 rounded-2xl font-semibold transition-colors">
                  View Analytics
                </button>
                <button className="w-full border-2 border-border hover:bg-muted py-3 rounded-2xl font-semibold transition-colors">
                  Manage Inventory
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-gradient-to-br from-primary/20 to-accent/30 rounded-3xl p-6 shadow-lg"
            >
              <h3 className="font-bold text-lg mb-2">Need Help?</h3>
              <p className="text-sm text-gray-600 mb-4">
                Check our documentation or contact support for assistance.
              </p>
              <button className="w-full bg-white hover:bg-gray-50 py-3 rounded-2xl font-semibold transition-colors">
                Contact Support
              </button>
            </motion.div>
          </div>
        </div>

        {/* Product Management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl p-6 shadow-lg mt-8"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-bold text-xl">Product Management</h2>
            <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-full font-semibold">
              + Add Product
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {products.slice(0, 4).map((product) => (
              <div key={product.id} className="border-2 border-border rounded-2xl p-4 hover:shadow-lg transition-shadow">
                <div className="aspect-square rounded-xl overflow-hidden bg-muted mb-3">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <h3 className="font-semibold mb-1 text-sm line-clamp-2">{product.name}</h3>
                <p className="text-lg font-black text-primary mb-3">${product.price}</p>
                <div className="flex gap-2">
                  <button className="flex-1 p-2 rounded-lg bg-accent hover:bg-primary/20 transition-colors">
                    <Eye className="h-4 w-4 mx-auto" />
                  </button>
                  <button className="flex-1 p-2 rounded-lg bg-primary/20 hover:bg-primary/30 transition-colors">
                    <Edit className="h-4 w-4 mx-auto" />
                  </button>
                  <button className="flex-1 p-2 rounded-lg bg-destructive/10 hover:bg-destructive/20 transition-colors">
                    <Trash2 className="h-4 w-4 mx-auto text-destructive" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
