export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  category: 'cars' | 'dolls' | 'games' | 'learning';
  ageRange: string;
  rating: number;
  reviews: number;
  image: string;
  description: string;
  inStock: boolean;
  features: string[];
}

export const products: Product[] = [
  {
    id: 1,
    name: "Super Speed Racing Car",
    price: 29.99,
    originalPrice: 39.99,
    category: "cars",
    ageRange: "3-8 years",
    rating: 4.8,
    reviews: 245,
    image: "https://images.unsplash.com/photo-1662321979743-3d0a327397bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3klMjBjYXJzJTIwY2hpbGRyZW58ZW58MXx8fHwxNzY3OTcxMTgzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "High-speed remote control car with LED lights and amazing stunts!",
    inStock: true,
    features: ["Remote controlled", "LED lights", "Durable design", "Rechargeable"]
  },
  {
    id: 2,
    name: "Princess Dress-Up Doll",
    price: 34.99,
    category: "dolls",
    ageRange: "4-10 years",
    rating: 4.9,
    reviews: 389,
    image: "https://images.unsplash.com/photo-1601361364311-950d35186297?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2xscyUyMHRveXN8ZW58MXx8fHwxNzY3OTcxMTg0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Beautiful princess doll with multiple dress options and accessories.",
    inStock: true,
    features: ["Multiple outfits", "Articulated joints", "Brush included", "High quality"]
  },
  {
    id: 3,
    name: "Educational Building Blocks",
    price: 24.99,
    originalPrice: 34.99,
    category: "learning",
    ageRange: "3-6 years",
    rating: 5.0,
    reviews: 512,
    image: "https://images.unsplash.com/photo-1761682753542-421c80ae8be2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb25hbCUyMHRveXMlMjBsZWFybmluZ3xlbnwxfHx8fDE3Njc5NzExODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Colorful building blocks to boost creativity and motor skills.",
    inStock: true,
    features: ["150+ pieces", "Safe materials", "Educational", "Colorful design"]
  },
  {
    id: 4,
    name: "Family Board Game Adventure",
    price: 39.99,
    category: "games",
    ageRange: "6-12 years",
    rating: 4.7,
    reviews: 198,
    image: "https://images.unsplash.com/photo-1672908871944-bf391a71cd12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwa2lkc3xlbnwxfHx8fDE3Njc5NzExODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Exciting board game for the whole family!",
    inStock: true,
    features: ["2-6 players", "30-60 min playtime", "Strategy game", "Family fun"]
  },
  {
    id: 5,
    name: "Monster Truck Collection",
    price: 44.99,
    category: "cars",
    ageRange: "4-10 years",
    rating: 4.6,
    reviews: 156,
    image: "https://images.unsplash.com/photo-1662321979743-3d0a327397bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3klMjBjYXJzJTIwY2hpbGRyZW58ZW58MXx8fHwxNzY3OTcxMTgzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Set of 4 rugged monster trucks with oversized wheels.",
    inStock: true,
    features: ["4 trucks included", "Oversized wheels", "Durable", "Great detail"]
  },
  {
    id: 6,
    name: "Science Lab Kit",
    price: 49.99,
    category: "learning",
    ageRange: "8-12 years",
    rating: 4.9,
    reviews: 287,
    image: "https://images.unsplash.com/photo-1761682753542-421c80ae8be2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb25hbCUyMHRveXMlMjBsZWFybmluZ3xlbnwxfHx8fDE3Njc5NzExODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Complete science lab with over 50 experiments!",
    inStock: false,
    features: ["50+ experiments", "Safety equipment", "Instruction guide", "STEM learning"]
  },
  {
    id: 7,
    name: "Fashion Designer Doll Set",
    price: 54.99,
    originalPrice: 69.99,
    category: "dolls",
    ageRange: "5-12 years",
    rating: 4.8,
    reviews: 423,
    image: "https://images.unsplash.com/photo-1601361364311-950d35186297?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2xscyUyMHRveXN8ZW58MXx8fHwxNzY3OTcxMTg0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Create your own fashion designs with this complete set!",
    inStock: true,
    features: ["Design kit", "Multiple dolls", "Fabric samples", "Creative fun"]
  },
  {
    id: 8,
    name: "Puzzle Adventure Game",
    price: 19.99,
    category: "games",
    ageRange: "4-8 years",
    rating: 4.5,
    reviews: 234,
    image: "https://images.unsplash.com/photo-1672908871944-bf391a71cd12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwa2lkc3xlbnwxfHx8fDE3Njc5NzExODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Fun puzzle game that challenges young minds!",
    inStock: true,
    features: ["100 piece puzzle", "Colorful design", "Educational", "Durable pieces"]
  },
];

export const categories = [
  { id: 'cars', name: 'Cars', icon: '🚗', count: products.filter(p => p.category === 'cars').length },
  { id: 'dolls', name: 'Dolls', icon: '🎎', count: products.filter(p => p.category === 'dolls').length },
  { id: 'games', name: 'Games', icon: '🎲', count: products.filter(p => p.category === 'games').length },
  { id: 'learning', name: 'Learning', icon: '📚', count: products.filter(p => p.category === 'learning').length },
];

export const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
    rating: 5,
    text: "Amazing quality! My kids absolutely love the toys from KIDO. Great customer service too!",
    date: "2 weeks ago"
  },
  {
    id: 2,
    name: "Michael Chen",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
    rating: 5,
    text: "Fast shipping and excellent products. The educational toys are fantastic for my daughter's development.",
    date: "1 month ago"
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emily",
    rating: 5,
    text: "Best toy store ever! Safe, fun, and educational toys. Highly recommend KIDO!",
    date: "3 weeks ago"
  },
];
