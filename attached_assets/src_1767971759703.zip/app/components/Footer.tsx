import { Link } from 'react-router-dom';
import { Star, Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-primary/10 via-accent/20 to-muted border-t-4 border-primary mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Star className="h-8 w-8 text-primary fill-primary" />
              <span className="text-2xl font-black text-primary">KIDO</span>
            </div>
            <p className="text-gray-600">
              Your trusted destination for safe, fun, and educational toys for children aged 3-12.
            </p>
            <div className="flex gap-3">
              <a href="#" className="p-2 rounded-full bg-primary hover:bg-secondary transition-colors">
                <Facebook className="h-5 w-5 text-white" />
              </a>
              <a href="#" className="p-2 rounded-full bg-primary hover:bg-secondary transition-colors">
                <Instagram className="h-5 w-5 text-white" />
              </a>
              <a href="#" className="p-2 rounded-full bg-primary hover:bg-secondary transition-colors">
                <Twitter className="h-5 w-5 text-white" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-600 hover:text-primary transition-colors">Home</Link></li>
              <li><Link to="/products" className="text-gray-600 hover:text-primary transition-colors">Shop</Link></li>
              <li><Link to="/cart" className="text-gray-600 hover:text-primary transition-colors">Cart</Link></li>
              <li><Link to="/login" className="text-gray-600 hover:text-primary transition-colors">My Account</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-bold text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/products?category=cars" className="text-gray-600 hover:text-primary transition-colors">Cars & Vehicles</Link></li>
              <li><Link to="/products?category=dolls" className="text-gray-600 hover:text-primary transition-colors">Dolls & Figures</Link></li>
              <li><Link to="/products?category=games" className="text-gray-600 hover:text-primary transition-colors">Board Games</Link></li>
              <li><Link to="/products?category=learning" className="text-gray-600 hover:text-primary transition-colors">Learning Toys</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-gray-600">
                <MapPin className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span>123 Toy Street, Fun City, FC 12345</span>
              </li>
              <li className="flex items-center gap-2 text-gray-600">
                <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2 text-gray-600">
                <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                <span>hello@kido.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-primary/20">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-600 text-center md:text-left">
              © 2026 KIDO. All rights reserved. Made with ❤️ for kids.
            </p>
            <div className="flex gap-6 text-sm text-gray-600">
              <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-primary transition-colors">Shipping Info</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
